void SCI_Init(void);
void SCI_SendByte(unsigned char byte ); 
unsigned char SCI_GetByte(void); 
void SCI_SendStr(char *s );
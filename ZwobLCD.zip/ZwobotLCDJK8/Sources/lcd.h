#ifndef LCD_INCLUDED
#define LCD_INCLUDED

extern void LCD_initialize(void);
extern char LCD_read(void);
extern void LCD_putchar(unsigned char x);
extern void LCD_clear(void);
extern void LCD_home(void);
extern void LCD_locate(unsigned char r,unsigned char c);
extern void LCD_clear_to( unsigned char r,unsigned char c );
extern void LCD_puts( char * s);
extern void LCD_putn( unsigned int n );
extern void LCD_linefeed(void);
static unsigned char row = 0;           /* current cursor position, row	    */
static unsigned char column = 0;        /* current cursor position, column  */



#endif



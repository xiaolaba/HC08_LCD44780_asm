/*************************************************************************************/
/*                                                                                   */
/* Funktionen f�r die RS232 Kommunikation mit dem Display                            */
/*                                                                                   */
/* Da das Display nicht antworten kann wird hier nur gesendet                        */
/*                                                                                   */
/* Format 9600 8N1                                                                   */
/*                                                                                   */
/*************************************************************************************/

#include <hidef.h>
#include <MC68HC908QB8.h>
#include "rs232.h"


/*************************************************************************************/
/*                                                                                   */
/* Init_SCI                                                                          */
/*                                                                                   */
/* SCI Initialisieren                                                                */
/*                                                                                   */
/*                                                                                   */
/*                                                                                   */
/*************************************************************************************/

void SCI_Init(void) 
{
SCC1 = 0x40;  /* 8 Bit No Parity 1 stop Bit  */
SCC2 = 0x2C;  /* Transmit enable receiver enable  Receive Interrupt enable */
SCBR = 0x03;  /* 9600 Baud bei fBus = 4.9152 MHz */
/* SCPSC = 0x00;  Prescaler Register              */
}

/*************************************************************************************/
/*                                                                                   */
/* SCI_Byte                                                                          */
/*                                                                                   */
/* Ein Byte senden                                                                   */
/*                                                                                   */
/*                                                                                   */
/*                                                                                   */
/*************************************************************************************/

void SCI_SendByte(unsigned char byte ) 
{
char transmitted;


transmitted = 0;

while(!transmitted) {
  transmitted = SCS1 & 0x40;
  }   	 
SCDR = byte;
}

/*************************************************************************************/
/*                                                                                   */
/* SCI_GetByte                                                                       */
/*                                                                                   */
/* Ein Byte empfangen                                                                */
/*                                                                                   */
/*                                                                                   */
/*                                                                                   */
/*************************************************************************************/



 
unsigned char SCI_GetByte(void) 
{

char received;

received = 0;
while ( !received ) {
  received = SCS1 & 0x20;
  }
return SCDR;
}

/*************************************************************************************/
/*                                                                                   */
/* SCI_SendStr                                                                       */
/*                                                                                   */
/* Eine Zeichenkette senden                                                          */
/*                                                                                   */
/*                                                                                   */
/*                                                                                   */
/*************************************************************************************/

void SCI_SendStr(char *s) {
 

    while (*s)
        SCI_SendByte(*s++);
}
  
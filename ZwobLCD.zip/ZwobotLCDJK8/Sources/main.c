#include <hidef.h> /* for EnableInterrupts macro */
#include "derivative.h" /* include peripheral declarations */
#include "hardware.h"
#include "lcd.h"
#include "wait.h"
#include "rs232.h"

volatile unsigned char databuf[40];
volatile unsigned char readptr,writeptr;


/***********************************************************************/
/*                                                                     */
/* getchar                        																		 */
/*                                                                     */
/* Holt ein Zeichen aus dem Empfangspuffer                             */
/*                                                                     */
/***********************************************************************/ 

unsigned char getchar()


{
if ( readptr == 40 ) {
  readptr = 0;
}

/* warten bis ein Zeichen angekommen ist */

while ( readptr == writeptr ){
}
return databuf[readptr++];
}


/***********************************************************************/
/*                                                                     */
/* MCU-Init                        																		 */
/*                                                                     */
/* Von Processor Expert erzeugter Initialisierungs code                */
/*                                                                     */
/* Enth�lt auch die Interrupt routinen                                 */
/* Die SCI Empfangsroutine ist auch dort zu finden                     */
/*                                                                     */
/*                                                                     */
/***********************************************************************/ 

void MCU_init(void); /* Device initialization function declaration */


/***********************************************************************/
/*                                                                     */
/* Main                          																		   */
/*                                                                     */
/* Initialisiert das Display, synchronisiert sich mit Zwobot           */
/* und interpretiert die Ausgabekommandos von Zwobot                   */
/*                                                                     */
/*                                                                     */
/***********************************************************************/ 

void main(void) {

unsigned char input;
signed char i;
int value;

  /* Uncomment this function call after using Device Initialization
     to use the generated code */
   MCU_init();

  EnableInterrupts; /* enable interrupts */

  /* include your code here */

readptr = 0;
writeptr = 0;
LCD_initialize();

LCD_puts("Zwobot LCD ready");

LCD_puts("Warte auf Zwobot");
wait_mS(100);
SCI_SendByte('a');
while(1){
  input = getchar();
  if ( input == '%' ) {
    input = getchar();
    
    switch (input) {
      case 'b':   
            input = getchar();
            for ( i=7; i >= 0; i--) {
                if (get_bit(input,i) == 1 ) {                 
                    LCD_putchar('1');                
                }
                else {                  
                    LCD_putchar('0');
                }
            }
            /* Byte als folge von Bits ausgeben */
            break;
      case 'n':
            input = getchar();
            LCD_putn(input);

            /* Byte numerisch ausgeben */
            break;
      case 'i' :
            input = getchar();
            value = 256*input;
            input = getchar();
            value = value + input;
            LCD_putn(value);
            /* 2 Byte Integer ausgeben */
            break;
      case 'l':
            input = getchar();
            LCD_locate ( input, column);
            /* zeile setzen */
            break;
      case 's':
            input = getchar();
            LCD_locate(row, input);
						/* spalte setzen */
						break;
      case 'p':
            row = getchar();
            column = getchar();
            LCD_locate( row, column );
						/* cursorposition setzen Byte 1 Zeile, Byte 2 Spalte */
						 break;
      case 'c':
            /* clear befehl f�r das LCD */
            LCD_clear();
            break;
      case '%':
            /* % Zeichen ausgeben */
            LCD_putchar('%');
            break;
						 
     } /* switch */
  } /* if */
  else {
        LCD_putchar(input);
  }
} /* while */


  /* please make sure that you never leave this function */
}

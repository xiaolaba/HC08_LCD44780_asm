/***********************************************************************/
/*                                                                     */
/* wait.h                         																		 */
/*                                                                     */
/* funktionen zum warten                                               */
/*                                                                     */
/***********************************************************************/ 

#ifndef WAIT_INCLUDED
#define WAIT_INCLUDED

extern void wait_x12_uS( unsigned char n );
extern void wait_x10_uS( unsigned char n );
extern void wait_mS( unsigned int n );

#endif
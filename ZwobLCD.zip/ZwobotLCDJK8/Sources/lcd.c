/*************************************************************************************/  
/*																																									 */
/* MODULE:   LCD.C																																	 */
/* Ansteuerun eines HDD44780 kompatiblem Displays im 4 Bit Modus  									 */
/*             stellt diverse funktionen zur positionierung                    		   */
/*             und formatierung der Ausgabe zur verf�gung.     							         */
/*																																									 */
/*************************************************************************************/


#include "hardware.h"
#include "lcd.h"
#include "wait.h"

#define LCD_COLUMNS 16    /* 16 Zeichen */
#define LCD_ROWS    2     /* 2 Zeilen   */
#define LCD_SIZE    ( LCD_COLUMNS * LCD_ROWS )


#define WAIT_15_mS wait_mS( 15 )
#define WAIT_40_uS wait_x12_uS(4)
#define WAIT_100_uS wait_x12_uS(10)


/*****************************************************************************/
/* You should not need to touch anything below this line                     */
/*****************************************************************************/



/* Kommando sequenz um das LCD zu Initialisieren ist hier gespeichert		 */
/* add here any additional command (e.g. special characters bitmaps)		 */

static const unsigned char cmd_setup[] = { 0x28, 0x28, 0x28, 0x08, 0x0f, 0x06, 0x02 };
    //                                       |     |     |     |     |     |     |
    // set interface mode to 4 bits----------+     |     |     |     |     |     |
    // (continue set interface mode)---------------+     |     |     |     |     |
    // function set--------------------------------------+     |     |     |     |
    // display off---------------------------------------------+     |     |     | 
    // display on----------------------------------------------------+     |     |
    // entry mode set------------------------------------------------------+     |
    // home----------------------------------------------------------------------+





/*****************************************************************************/
/* LCD_busyflag - waits until Busy Flag is clear                             */
/*****************************************************************************/

static void LCD_busyflag(void)
{

char busy;
char old_cd;

	old_cd = LCD_RS;
/*	LCD_DB7_DDR = 0;        Datenleitungen als Eingang */
/*  LCD_DB6_DDR = 0;																	 */
/*  LCD_DB5_DDR = 0;																	 */
/*  LCD_DB4_DDR = 0;																	 */

  PTB = PTB & 0xF0;
  DDRB = DDRB  & 0x0F;																 
	LCD_RW = 1;                 /* Jetzt lesen  */
	LCD_RS = 0;                 /* Status Byte  */
    do
        {    
         LCD_E = 1;              /* strobe ENABLE line */
         asm {
             NOP 
             }                     
         if ( LCD_DB7 ==1 ) {
            busy = 1 ;          
            }
         else {
            busy =0 ;
            }   
         LCD_E =0;
         asm {
              NOP
         }
         LCD_E = 1;	 /* 2tes Nibble lesen */
         asm {
             NOP
             } 
         LCD_E = 0;  
         asm {
             NOP 
             }                   
        }
    while (busy ) ;
    
    LCD_RW = 0;
    LCD_RS = old_cd;
    DDRB = DDRB | 0xF0;
    
 /*   LCD_DB7_DDR = 1;
    LCD_DB6_DDR = 1;
    LCD_DB5_DDR = 1;
    LCD_DB4_DDR = 1; */


}


/*****************************************************************************/
/* LCD_read - Ein Byte vom Display lesen                                     */
/*****************************************************************************/

static char LCD_read(void)
{

char datahigh, datalow;
char old_cd;

	old_cd = LCD_RS;

  PTB = PTB & 0xF0;
  DDRB = DDRB  & 0x0F;																 
	LCD_RW = 1;                 /* Jetzt lesen  */
	LCD_RS = 0;                 /* Status Byte  */
         LCD_E = 1;              /* strobe ENABLE line */
         asm {
             NOP 
             }                     
             datahigh = PTB & 0xF0;
         LCD_E =0;
         asm {
              NOP
         }
         LCD_E = 1;	 /* 2tes Nibble lesen */
         asm {
             NOP
             } 
             datalow = ( PTB & 0xf0 ) >> 4;
         LCD_E = 0;  
         asm {
             NOP 
             }                   

    
    LCD_RW = 0;
    LCD_RS = old_cd;
    DDRB = DDRB | 0xF0;
    return ( datahigh + datalow );
}

/*****************************************************************************/
/* LCD_nibble - puts a 4-bit command to  the display                         */
/*****************************************************************************/

static void LCD_nibble( unsigned char x )
{
    LCD_DB7 = get_bit(x, 3);    /*extract bit 3 from byte x		*/
    LCD_DB6 = get_bit(x, 2);    /*...then bit 2, 1 and 0			*/
    LCD_DB5 = get_bit(x, 1);    
    LCD_DB4 = get_bit(x, 0);

    LCD_E = 1;                  /*strobe ENABLE line					 */
    _asm nop
    _asm nop
    LCD_E = 0;
}


 
/*****************************************************************************/
/* LCD_write - puts a byte to  the display as two 4-bit nibbles              */
/* keeps current RS setting, the byte can be either a command or data        */
/*****************************************************************************/

static void LCD_write( unsigned char c )
{
    LCD_nibble( c >> 4 );
    LCD_nibble( c );
//    WAIT_40_uS;  
    LCD_busyflag();   
}



/*****************************************************************************/
/* LCD_linefeed - movers cursor location to the start of the next line       */
/* (rolls over display end)                                                  */
/*****************************************************************************/

void LCD_linefeed(void)
{
    row = (unsigned char) ( ( row + 1 ) % LCD_ROWS );
    column = 0;
    LCD_locate( row, column );
}

/*****************************************************************************/
/* LCD_clear - l�scht das Display und setzt die Cursor Position auf 0,0      */
/*                                                                           */
/*****************************************************************************/

void LCD_clear(void)
{
    LCD_RS =0;                   /* kommando modus setzen */
    LCD_write(0x01);						 /* clear kommando an LCD senden */
    LCD_RS = 1;									 /* zur�ck zum daten modus */
    row = 0;
    column = 0;
    LCD_busyflag();    
 //   WAIT_15_mS;
    LCD_home();

}


/*****************************************************************************/
/* LCD_clear - l�scht das Display und setzt die Cursor Position auf 0,0      */
/*                                                                           */
/*****************************************************************************/

void LCD_home(void)
{
    LCD_RS =0;                   /* kommando modus setzen */
    LCD_write(0x02);						 /* home kommando an LCD senden */
    LCD_RS = 1;									 /* zur�ck zum daten modus */
    row = 0;
    column = 0;
    LCD_busyflag();    
//    WAIT_40_uS;
}


/*****************************************************************************/
/* LCD_locate - moves the cursor to a row, column                            */
/*****************************************************************************/

void LCD_locate( unsigned char r,unsigned char c )
{
    unsigned char ram_address = c + r*64;
    row = r;
    column = c;
    LCD_RS = 0;                         //switch to command mode
    LCD_write( 0x80 | ram_address );    //set display ram address
    LCD_RS = 1;   
    LCD_busyflag();
//    WAIT_40_uS;                     //back to character mode
}



/*****************************************************************************/
/* LCD_clear_to - advances the cursor from current location to row, column   */
/* clearing all characterh in between                                        */
/*****************************************************************************/

void LCD_clear_to( unsigned char r, unsigned char c )
{
    while (r != row && c != column)
        LCD_putchar( ' ' );
}



/*****************************************************************************/
/* LCD_putchar - writes a character and advances cursor location             */
/* interprets printf-style escapes:                                          */
/*     \r = "carriage return" brings cursor to leftmost column               */
/*     \f = "form-feed" simulates a page clear                               */
/*     \n = "newline" brings cursor to start of next line                    */
/*****************************************************************************/

void LCD_putchar( unsigned char c )
{
    switch( c )
    {
    case '\r':     /* the "carriage return" escape brings cursor to leftmost column */
            LCD_locate( row, 0);
            break;
            
    case '\f':     /* the "form-feed" escape simulates a page clear   */
            {       unsigned char i;
                    LCD_locate( 0, 0 );
                    for ( i=0; i<LCD_SIZE; i++ )
                            LCD_write(' ');
            }
            break;
            
    case '\n':     /* the "newline" escape brings to start of next line   */
            LCD_linefeed();
            break;          
            
    default:
            LCD_write( c );
            if ( ++column == LCD_COLUMNS )
                LCD_linefeed();
    }
}



/*****************************************************************************/
/* LCD_initialize - initializes hardware and display                         */
/*****************************************************************************/

void LCD_initialize(void)
{
        unsigned char i;
        
        LCD_E_DDR   = 1;
        LCD_RS_DDR  = 1;
        LCD_RW_DDR  = 1;
        LCD_DB7_DDR = 1;
        LCD_DB6_DDR = 1;
        LCD_DB5_DDR = 1;
        LCD_DB4_DDR = 1;

        LCD_RW = 0;
        LCD_RS = 0;
        LCD_E  = 0;
        WAIT_15_mS;

        for ( i=0; i < sizeof( cmd_setup ); i++)
        { 
                WAIT_15_mS;
                LCD_write( cmd_setup[i] ); 
        };
        WAIT_15_mS;
        LCD_RS = 1;
}
   
   
   
/*****************************************************************************/
/* LCD_puts - puts a string to LCD                                           */      
/* it accepts escape sequences embedded on string                            */
/* e.g. "\fFIRST LINE\nSECOND LINE" clears the display, writes "FIRST LINE   */
/* on the first line and "SECOND LINE" on the second                         */
/*****************************************************************************/

void LCD_puts( char * s )
{
    while (*s)
        LCD_putchar(*s++);
}


/*****************************************************************************/
/* LCD_putn - prints a unsigned integer number to LCD                        */
/*****************************************************************************/

void LCD_putn( unsigned int n )
{
    unsigned char i = 0;
    unsigned char buf[5];       //integers need at most 5 digits    
    
    do                          //fill the buffer iteratively...
    {
        buf[i++] = '0' + n % 10;
        n = n / 10;
    } while (n != 0);
    
     
    while( i > 0)               //...and print it backwards
    {
        LCD_putchar( buf[ --i ] );
    }
}


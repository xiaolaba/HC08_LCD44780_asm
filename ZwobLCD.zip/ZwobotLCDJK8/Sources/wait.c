/**************************************************************************************/  
/*																																										*/
/* wait.c           																																  */
/* wartefunktionen basierend auf ROM routinen                													*/
/* Adressen nur f�r  HC908JK8   																											*/
/*           siehe auch: AN2346, AN1831 f�r ROM information 													*/
/* Zeiten sind Mindestzeiten und evtl l�nger                                    			*/
/*																																										*/
/**************************************************************************************/

#include "wait.h"

#define DELNUS 0xFD35       /*ROM routine address for delay*/



/****************************************************************************/
/* wait_x12_uS - wait the specified number of 12 uS units                   */
/****************************************************************************/

void wait_x10_uS( unsigned char n )
{
unsigned char i;


while (n--)  {
   for (i=0; i<=12; i++) {
    _asm nop;
    _asm nop;
  }
}
}

/****************************************************************************/
/* wait_x12_uS - wait the specified number of 12 uS units                   */
/****************************************************************************/

void wait_x12_uS( unsigned char n )
{
    _asm ldx n;             //X = number of 12 uS units
    _asm lda 20;            //CPU CLOCK / 250 kHz = 20
    _asm jsr DELNUS;        //call ROM delay routine
}


/*****************************************************************************/
/* wait_mS - wait the specified number of mS                                 */
/*****************************************************************************/

void wait_mS( unsigned int n )
{
    while( n--)
        wait_x12_uS( 84 );  // 1000 uS / 12 uS = 84
}
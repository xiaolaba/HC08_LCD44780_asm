/***************************************************************/
/* HARDWARE.H																				      		 */
/*																														 */
/* Hardware register/pin configuration												 */
/*																												  	 */
/***************************************************************/


#ifndef HARDWARE_INCLUDED
#define HARDWARE_INCLUDED

#include <MC68HC908JK8.h>
#include <hidef.h>
#define CLOCK_FREQUENCY 19660800

/*************************************************************/
/* LCD MODULE PIN DEFINITIONS																 */
/*************************************************************/

#define LCD_E           PTD_PTD3   // Enable (strobe) pin
#define LCD_RS          PTD_PTD4   // Command/data selector, sometimes named R/S
#define LCD_RW          PTD_PTD2   // Read/Write Pin

#define LCD_DB7         PTB_PTB7  // Data pin, bits 7..4 (other pins unconnected)
#define LCD_DB6         PTB_PTB6   //
#define LCD_DB5         PTB_PTB5   //
#define LCD_DB4         PTB_PTB4   //


#define LCD_E_DDR       DDRD_DDRD3 // data direction register bits for
#define LCD_RS_DDR      DDRD_DDRD4  // all of the pins above
#define LCD_RW_DDR		  DDRD_DDRD2  
                                    //
#define LCD_DB7_DDR     DDRB_DDRB7  //
#define LCD_DB6_DDR     DDRB_DDRB6  //
#define LCD_DB5_DDR     DDRB_DDRB5  //
#define LCD_DB4_DDR     DDRB_DDRB4  //




/***************************************************************/
/* some useful macros when toggling bits											 */
/***************************************************************/

#define bin( x7, x6, x5, x4, x3, x2, x1, x0) ((x7)*128 + (x6)*64 + (x5)*32 + (x4)*16 + (x3)*8 + (x2)*4 + (x1)*2 +(x0) )

#define get_bit( x, n ) ( ( (x) & ( 1 << (n) ) ) != 0 )
#define set_bit( x, n ) { (x) |=  ( 1 << (n) ); } 
#define clr_bit( x, n ) { (x) &= ~( 1 << (n) ); } 








#endif